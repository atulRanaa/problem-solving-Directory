import pandas as pd
import numpy as np
import math
from sklearn.cluster import k_means
from scipy.spatial import distance


def compute_s_i(data,labels,centroids,n):
	s_i = np.array([0.0]*n)
	size_of_data = len(labels)
	size_of_cluster = np.array([0]*n)

	for i in range(size_of_data):
	    s_i[ labels[i] ] += np.linalg.norm(data[i]-centroids[ labels[i] ])
	    size_of_cluster[ labels[i] ] +=1
	for i in range(n):
		s_i[i] /= size_of_cluster[i]
	return s_i

def compute_r_ij(s_i,centroids,n,i):
	r_ij = []
	for j in range(n):
		if i!=j:
			r_ij += [ (s_i[i]+s_i[j])/np.linalg.norm(centroids[i]-centroids[j]) ]
	return r_ij

def compute_sigma_r_i(s_i,centroids,n):
	sigma_r_i = 0.0
	for i in range(n):
		r_ij = compute_r_ij(s_i,centroids,n,i)
		sigma_r_i += max(r_ij)
	return sigma_r_i


def main():
	dbindex = None

	df = pd.read_csv("Dataset_Round1_Assignment 1 (of 2)_Programmer.csv")
	df=df.dropna()

	df1 = df.copy()
	del df1['Customer']
	del df1['Effective To Date']

	df2 = pd.get_dummies(df1)
	n = 10
	clf = k_means(df2,n_clusters=n)

	data = np.array(df2)
	centroids = clf[0]
	labels = clf[1]

	s_i = compute_s_i(data,labels,centroids,n)
	sigma_r_i = compute_sigma_r_i(s_i,centroids,n)

	dbindex = sigma_r_i/n
	print("Davies Bouldin Index for %d clusters is %0.20f"%(n,dbindex))

if __name__ == '__main__':
	main()
