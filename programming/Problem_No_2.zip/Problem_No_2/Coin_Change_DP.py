# Space Complexity: O(N)
# Time Complexity: O(N*n)
# Considering 2**32 as INT_MAX
def findMinCoins(S,n,N):
	T = [0]*(N+1)
	for i in range(1,N+1):
		T[i] = (1<<32)
		res = (1<<32)

		for c in range(n):
			if i-S[c] >= 0: res = T[ i-S[c] ]
			if res!= (1<<32):
				T[i] = min(T[i],res+1)
	return T[N]

def main():
	S = [1,2,3,4]
	n = len(S)

	N = 15
	print "Minimum number of coins required to get desired change is %d"%(findMinCoins(S,n,N))

if __name__ == '__main__':
	main()
