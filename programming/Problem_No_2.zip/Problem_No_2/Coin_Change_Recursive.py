# Consider 2**32 as INT_MAX
# Space Complexity: O(n*min(S)) due to stack formation
# Time Complexity: Exponential formation if tree of n nodes for every changed value of N
def findMinCoins(S,n,N):
	if N==0: return 0
	if N <0: return (1<<32)

	coins = (1<<32)
	for i in range(n):
		res = findMinCoins(S,n,N-S[i])
		if res != (1<<32):
			coins = min(coins,res+1)
	return coins
def main():
	S = [1,2,3,4]
	n = len(S)

	N = 15
	print "Minimum number of coins required to get desired change is %d"%(findMinCoins(S,n,N))

if __name__ == '__main__':
	main()
